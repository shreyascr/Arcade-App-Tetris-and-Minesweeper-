# Tetris and Minesweeper Game
This is java application that allows the user to play Tetris and Minesweeper.
